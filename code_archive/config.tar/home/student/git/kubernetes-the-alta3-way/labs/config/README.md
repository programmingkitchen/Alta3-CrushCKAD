# This is the location for all kubernetes course (non-yaml) configuration files
