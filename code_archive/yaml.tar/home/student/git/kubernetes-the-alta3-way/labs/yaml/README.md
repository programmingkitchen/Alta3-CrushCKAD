# This is the location for all kubernetes course yaml files
